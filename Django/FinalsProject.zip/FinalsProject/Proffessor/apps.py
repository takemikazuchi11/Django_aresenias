from django.apps import AppConfig


class ProffessorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Proffessor'
